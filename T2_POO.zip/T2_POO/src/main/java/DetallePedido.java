public class DetallePedido {
    private Producto producto;
    private int cantidad;
    private double precioUnitario;

    public DetallePedido(Producto producto, int cantidad) {
        setProducto(producto);
        setCantidad(cantidad);
        setPrecioUnitario(producto.calcularPrecioFinal());
    }

    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) {
        if (producto == null) { throw new IllegalArgumentException("El producto es obligatorio"); }
        this.producto = producto;
    }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) {
        if (cantidad <= 0) { throw new IllegalArgumentException("La cantidad debe ser mayor que cero"); }
        this.cantidad = cantidad;
    }
    public double getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(double precioUnitario) {
        if (Double.isNaN(precioUnitario) || Double.isInfinite(precioUnitario) || precioUnitario <= 0) {
            throw new IllegalArgumentException("El precio unitario debe ser mayor que cero");
        }
        this.precioUnitario = precioUnitario;
    }
    public double calcularSubtotal() { return cantidad * precioUnitario; }
    public String mostrarDatos() {
        return producto.getNombre() + " | Cantidad: " + cantidad + " | Precio unitario: S/ "
                + precioUnitario + " | Subtotal: S/ " + calcularSubtotal();
    }
}
