import java.util.ArrayList;

public class Cliente {
    private String dni;
    private String nombre;
    private ArrayList<Pedido> pedidos;

    public Cliente(String dni, String nombre) {
        setDni(dni);
        setNombre(nombre);
        pedidos = new ArrayList<Pedido>();
    }

    public String getDni() { return dni; }
    public void setDni(String dni) {
        if (dni == null || dni.trim().length() != 8) {
            throw new IllegalArgumentException("El DNI debe tener 8 caracteres");
        }
        for (int i = 0; i < dni.length(); i++) {
            if (dni.charAt(i) < '0' || dni.charAt(i) > '9') {
                throw new IllegalArgumentException("El DNI solo debe contener numeros");
            }
        }
        this.dni = dni;
    }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().length() == 0) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio");
        }
        this.nombre = nombre.trim();
    }
    public ArrayList<Pedido> getPedidos() { return new ArrayList<Pedido>(pedidos); }
    public void agregarPedido(Pedido pedido) {
        if (pedido == null || pedido.getCliente() != this) {
            throw new IllegalArgumentException("El pedido debe pertenecer a este cliente");
        }
        if (!pedidos.contains(pedido)) { pedidos.add(pedido); }
    }
    public String mostrarDatos() {
        return "Cliente: " + nombre + " | DNI: " + dni + " | Pedidos: " + pedidos.size();
    }
}
