public final class ProductoDigital extends Producto implements Vendible, Mostrable {
    private double porcentajeLicencia;

    public ProductoDigital(String codigo, String nombre, double precioBase, double porcentajeLicencia) {
        super(codigo, nombre, precioBase);
        setPorcentajeLicencia(porcentajeLicencia);
    }

    public double getPorcentajeLicencia() { return porcentajeLicencia; }
    public void setPorcentajeLicencia(double porcentajeLicencia) {
        if (Double.isNaN(porcentajeLicencia) || Double.isInfinite(porcentajeLicencia)
                || porcentajeLicencia < 0 || porcentajeLicencia > 100) {
            throw new IllegalArgumentException("El porcentaje de licencia debe estar entre 0 y 100");
        }
        this.porcentajeLicencia = porcentajeLicencia;
    }

    @Override
    public double calcularPrecioFinal() {
        return getPrecioBase() + getPrecioBase() * porcentajeLicencia / 100;
    }

    @Override
    public String mostrarDatos() {
        return "Producto digital | " + super.mostrarDatos() + " | Licencia: " + porcentajeLicencia
                + "% | Precio final: S/ " + calcularPrecioFinal();
    }
}
