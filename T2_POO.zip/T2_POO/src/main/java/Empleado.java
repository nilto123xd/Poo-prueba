import java.util.ArrayList;

public class Empleado {
    private int codigo;
    private String nombre;
    private Empleado jefe;
    private ArrayList<Empleado> subordinados;

    public Empleado(int codigo, String nombre) {
        setCodigo(codigo);
        setNombre(nombre);
        subordinados = new ArrayList<Empleado>();
    }

    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) {
        if (codigo <= 0) { throw new IllegalArgumentException("El codigo del empleado debe ser positivo"); }
        this.codigo = codigo;
    }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().length() == 0) {
            throw new IllegalArgumentException("El nombre del empleado es obligatorio");
        }
        this.nombre = nombre.trim();
    }
    public Empleado getJefe() { return jefe; }
    public ArrayList<Empleado> getSubordinados() { return new ArrayList<Empleado>(subordinados); }
    public void asignarJefe(Empleado nuevoJefe) {
        if (nuevoJefe == this) { throw new IllegalArgumentException("Un empleado no puede ser su propio jefe"); }
        Empleado actual = nuevoJefe;
        while (actual != null) {
            if (actual == this) { throw new IllegalArgumentException("La jerarquia no puede tener ciclos"); }
            actual = actual.getJefe();
        }
        if (jefe != null) { jefe.subordinados.remove(this); }
        jefe = nuevoJefe;
        if (jefe != null && !jefe.subordinados.contains(this)) { jefe.subordinados.add(this); }
    }
    public String mostrarDatos() {
        String nombreJefe = "Sin jefe";
        if (jefe != null) { nombreJefe = jefe.getNombre(); }
        return "Empleado: " + nombre + " | Codigo: " + codigo + " | Jefe: " + nombreJefe
                + " | Subordinados: " + subordinados.size();
    }
}
