public final class ProductoFisico extends Producto implements Vendible, Mostrable {
    private double costoEnvio;

    public ProductoFisico(String codigo, String nombre, double precioBase, double costoEnvio) {
        super(codigo, nombre, precioBase);
        setCostoEnvio(costoEnvio);
    }

    public double getCostoEnvio() { return costoEnvio; }
    public void setCostoEnvio(double costoEnvio) {
        if (Double.isNaN(costoEnvio) || Double.isInfinite(costoEnvio) || costoEnvio < 0) {
            throw new IllegalArgumentException("El costo de envio no puede ser negativo");
        }
        this.costoEnvio = costoEnvio;
    }

    @Override
    public double calcularPrecioFinal() { return getPrecioBase() + costoEnvio; }

    @Override
    public String mostrarDatos() {
        return "Producto fisico | " + super.mostrarDatos() + " | Envio: S/ " + costoEnvio
                + " | Precio final: S/ " + calcularPrecioFinal();
    }
}
