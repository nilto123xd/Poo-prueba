public abstract class Producto {
    private String codigo;
    private String nombre;
    private double precioBase;

    public Producto(String codigo, String nombre, double precioBase) {
        setCodigo(codigo);
        setNombre(nombre);
        setPrecioBase(precioBase);
    }

    private String validarTexto(String valor, String mensaje) {
        if (valor == null || valor.trim().length() == 0) {
            throw new IllegalArgumentException(mensaje);
        }
        return valor.trim();
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = validarTexto(codigo, "El codigo es obligatorio"); }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = validarTexto(nombre, "El nombre es obligatorio"); }
    public double getPrecioBase() { return precioBase; }
    public void setPrecioBase(double precioBase) {
        if (Double.isNaN(precioBase) || Double.isInfinite(precioBase) || precioBase <= 0) {
            throw new IllegalArgumentException("El precio base debe ser mayor que cero");
        }
        this.precioBase = precioBase;
    }

    public abstract double calcularPrecioFinal();

    public String mostrarDatos() {
        return "Codigo: " + codigo + " | Nombre: " + nombre + " | Precio base: S/ " + precioBase;
    }
}
