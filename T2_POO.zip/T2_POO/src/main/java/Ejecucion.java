import java.util.ArrayList;

public class Ejecucion {
    public static void main(String[] args) {
        try {
            ProductoFisico teclado = new ProductoFisico("F001", "Teclado mecanico", 150, 20);
            ProductoDigital licencia = new ProductoDigital("D001", "Licencia antivirus", 100, 10);

            ArrayList<Producto> productos = new ArrayList<Producto>();
            productos.add(teclado);
            productos.add(licencia);

            System.out.println("=== PRODUCTOS Y POLIMORFISMO ===");
            for (int i = 0; i < productos.size(); i++) {
                Producto producto = productos.get(i);
                System.out.println(producto.mostrarDatos());
                System.out.println("Precio final polimorfico: S/ " + producto.calcularPrecioFinal());
            }

            System.out.println("=== INTERFACES ===");
            Vendible venta = teclado;
            Mostrable informacion = licencia;
            System.out.println("Precio desde Vendible: S/ " + venta.calcularPrecioFinal());
            System.out.println("Datos desde Mostrable: " + informacion.mostrarDatos());

            Cliente cliente = new Cliente("12345678", "Ana Torres");
            Pedido pedido1 = new Pedido(1, cliente);
            pedido1.agregarDetalle(teclado, 2);
            pedido1.agregarDetalle(licencia, 3);
            Pedido pedido2 = new Pedido(2, cliente);
            pedido2.agregarDetalle(licencia, 1);

            System.out.println("=== CLIENTE Y PEDIDOS ===");
            System.out.println(cliente.mostrarDatos());
            System.out.println(pedido1.mostrarDatos());
            System.out.println(pedido2.mostrarDatos());

            Empleado jefe = new Empleado(1, "Carlos Ruiz");
            Empleado trabajador = new Empleado(2, "Luis Perez");
            trabajador.asignarJefe(jefe);
            System.out.println("=== EMPLEADOS ===");
            System.out.println(jefe.mostrarDatos());
            System.out.println(trabajador.mostrarDatos());

            System.out.println("=== PRUEBA DE VALIDACION ===");
            try {
                new DetallePedido(teclado, 0);
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
