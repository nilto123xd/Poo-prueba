public interface Mostrable {
    String mostrarDatos();
}
