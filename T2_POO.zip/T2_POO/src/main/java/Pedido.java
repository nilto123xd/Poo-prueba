import java.util.ArrayList;

public class Pedido {
    private int numero;
    private Cliente cliente;
    private ArrayList<DetallePedido> detalles;

    public Pedido(int numero, Cliente cliente) {
        setNumero(numero);
        setCliente(cliente);
        detalles = new ArrayList<DetallePedido>();
        cliente.agregarPedido(this);
    }

    public int getNumero() { return numero; }
    public void setNumero(int numero) {
        if (numero <= 0) { throw new IllegalArgumentException("El numero de pedido debe ser positivo"); }
        this.numero = numero;
    }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) {
        if (cliente == null) { throw new IllegalArgumentException("El cliente es obligatorio"); }
        if (this.cliente != null && this.cliente != cliente) {
            throw new IllegalArgumentException("No se puede cambiar el cliente del pedido");
        }
        this.cliente = cliente;
    }
    public ArrayList<DetallePedido> getDetalles() { return new ArrayList<DetallePedido>(detalles); }
    public void agregarDetalle(Producto producto, int cantidad) {
        detalles.add(new DetallePedido(producto, cantidad));
    }
    public double calcularTotal() {
        double total = 0;
        for (int i = 0; i < detalles.size(); i++) {
            total = total + detalles.get(i).calcularSubtotal();
        }
        return total;
    }
    public String mostrarDatos() {
        String resultado = "Pedido N. " + numero + " | Cliente: " + cliente.getNombre() + "\n";
        for (int i = 0; i < detalles.size(); i++) {
            resultado = resultado + detalles.get(i).mostrarDatos() + "\n";
        }
        return resultado + "TOTAL: S/ " + calcularTotal();
    }
}
